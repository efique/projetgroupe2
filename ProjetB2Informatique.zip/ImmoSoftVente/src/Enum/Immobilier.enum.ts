export enum ImmobilierEnum {
  MAISON = 'Maison',
  APPARTEMENT = 'Appartement',
  STUDIO = 'Studio',
}
