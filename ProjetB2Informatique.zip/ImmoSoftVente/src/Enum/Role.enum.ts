export enum RoleEnum {
  UTILISATEUR = 'Utilisateur',
  VENDEUR = 'Vendeur',
  AGENTIMMOBILIER = 'Agent Immobilier',
  ADMINISTRATEUR = 'Administrateur',
  SYSADMINISTRATEUR = 'SysAdmin',
}
