export enum DependancesEnum {
  JARDIN = 'Jardin',
  GARAGE = 'Garage',
  TERASSE = 'Terasse',
  VERANDA = 'Veranda',
  CAVE = 'Cave',
}
