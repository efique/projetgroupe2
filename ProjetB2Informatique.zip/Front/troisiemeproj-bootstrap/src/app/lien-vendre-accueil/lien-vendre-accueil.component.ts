import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lien-vendre-accueil',
  templateUrl: './lien-vendre-accueil.component.html',
  styleUrls: ['./lien-vendre-accueil.component.css']
})
export class LienVendreAccueilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
