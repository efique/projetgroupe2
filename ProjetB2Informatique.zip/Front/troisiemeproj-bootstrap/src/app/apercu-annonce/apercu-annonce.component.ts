import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apercu-annonce',
  templateUrl: './apercu-annonce.component.html',
  styleUrls: ['./apercu-annonce.component.css']
})
export class ApercuAnnonceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
